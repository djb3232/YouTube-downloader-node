const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static('.'));
app.use(express.json());

app.post('/api/download', async (req, res) => {
  const { url, type, quality } = req.body;

  if (!url || !type || !quality) {
    return res.status(400).json({ error: 'Missing data' });
  }

  const videoId = new URLSearchParams(new URL(url).search).get('v');
  if (!videoId) {
    return res.status(400).json({ error: 'Invalid YouTube URL' });
  }

  const base = 'https://youtube-video-fast-downloader-24-7.p.rapidapi.com/';
  const endpoint = type === 'audio'
    ? `download_audio/${videoId}?quality=${quality}`
    : `download_video/${videoId}?format=mp4&quality=${quality}`;

  const options = {
    method: 'GET',
    headers: {
      'x-rapidapi-host': 'youtube-video-fast-downloader-24-7.p.rapidapi.com',
      'x-rapidapi-key': '6bd43df79bmsh96858e8b2050591p111021jsnec8b64e42d05'
    }
  };

  try {
    const response = await fetch(base + endpoint, options);
    const data = await response.json();
    if (data.link) {
      res.json({ link: data.link });
    } else {
      res.status(502).json({ error: data.message || 'No link found' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
